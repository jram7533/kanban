/*
    jQ for kanban
    
    Name:           kanban.js
    Author:         Jack Ramsey
    Date:           12/30/2019
    Purpose:        Functionality for kanban board, including
                    - drag and drop functionality
                    - open/close modal
                    - take user input and create new card
                    - append new jobs to table
                    - delete jobs on user demand
*/
$.ajaxSetup({
  cache: false
});

$(document).ready(function() {
    //$.ajaxSetup({cache: false}});
    
// get current table data   
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'data/data.dat', false);
    xhr.send(null);
    $('#tab').html(xhr.responseText);
///////////////////    
    
// variables 
    var cards = $('.card-outer');       // get all cards
    var cells = $('td');                // get all table cells
    var closers = $('.close');          // close spans
    var closeModal = $('#close-modal'); // close-modal span
    var modal = $('#modal');            // modal
    var add = $('#add');                // add job button
    var save = $('#save');              // save sheet button
    var submit = $('#submit');          // submit button
///////////////////
    
    // initialize drag, drop, and close events
    // make table cells droppable
    cells.droppable( {
        drop: handleDropEvent
    });
    
    // make cards draggable
    cards.draggable( {
        snap: 'td',
        cursor: 'move'
    });
    
    // drop event, if needed
    function handleDropEvent( event, ui ) {
        var draggable = ui.draggable;
    }
    
    // remove a row when closer clicked
    closers.click( function(){
        $(this).parents("tr").remove();
        saveTable();

    });
    ///////////////////////////////////////////
    
    // add a new row for a new job
    function addNewRow(n) {        
        var newCard = buildNewCard(job, owner, desc);
        
        var markup = "<tr><td>" + n + "</td><td></td><td></td></tr>";
        $('#tab > tbody > tr').eq(0).after(markup);
        
        // re-register drag, drop, and close events
        // for new row
        cards = $('.card-outer');
        cards.draggable( {
            snap: 'td',
            cursor: 'move'
        });
        
        cells = $('td');
        cells.droppable();
        
        closers = $('.close');
        closers.click( function(){
            $(this).parents("tr").remove();
        });
        
        saveTable();

        ///////////////////////////////////////////
    }
    
    // close modal 
    closeModal.click( function() {
        modal.fadeOut(500); 
//        modal.css('display', 'none') 
    });
    
    // open modal
    add.click( function() {
        modal.fadeIn(500);
    });
    
    save.click( function() {
        saveTable();
    });
    
    function saveTable() {
        var tableData = $('#tab').html();
        
        var url ="php/save.php";
        $.post(url, { tableData:tableData }, function(data){
//        console.log('response from the callback function: '+ data); 
        }).fail(function(jqXHR){
             alert(jqXHR.status +' '+jqXHR.statusText+ ' $.post failed!');
        });
    }
    
    // submit new record
    submit.click(function() {
        var job = $('#job').val();
        var owner = $('#owner').val();
        var desc = $('#desc').val();
        var assign = $('#assigned').val();
        var due = $('#due').val();
        var priority = $("input[name='priority']:checked").val();
        
        var valid = validateForm(job, owner, desc, assign, due, priority);
        
        if (valid) {        
            modal.fadeOut(500);

            addNewRow(buildNewCard(job, owner, desc, assign, due, priority));
            saveTable();
            
            // reset form fields for next add
            $('#job').val('')
            $('#owner').val('');
            $('#desc').val('');
            $('#assigned').val('');
            $('#due').val('');
            $('#radio1').attr('checked', true);
        }
    });
    
    // create new row with input values
    function buildNewCard(j, o, d, a, due, p) {
        
        var s = '';
        
        switch(p) {
            case 'low':
                s = "style='background:green'";
                break;
            case 'med':
                s = "style='background:blue'";
                break;
            case 'high':
                s = "style='background:red'" ;
                break;                
        } 
        
        console.log(s)
        
        var out = "<div class='card-outer'>" +         
                    "<div class='card-inner'>" +
                        "<span class='close'><i class='fa fa-close'></i></span>" +
                        "<header " + s + ">"  + j + "</header>" + 
                        "<div class='card-content'>" + d + "</div>" +                    
                        "<div class='dates'>" +
                            "<label>Assigned: </label>" + "<span>" + a + "</span>" + 
                            "<label>Due: </label>" + "<span>" + due + "</span>" +
                        "</div>" +
                        "<div id='footer' class='footer'>" +
                            "Owner: <span>" + o + "</span" +
                        "</div>" +
                    "</div>" +
                "</div>";
        return out;
    }
    
    function validateForm(job, owner, desc, assign, due) {
        var a = new Date(assign);
        var d = new Date(due); 
        
        if (!job || !owner || !desc || !assign) {
            alert('Please complete all fields!\n(Due date optional)');
            return false;
        } else if(d.getTime() < a.getTime()) {
            alert('Due date cannot come before assignment date!');
            return false 
        } else {
            return true;
        }
    }
    
    $(window).unload(function() {
        saveTable();
    });
    
});